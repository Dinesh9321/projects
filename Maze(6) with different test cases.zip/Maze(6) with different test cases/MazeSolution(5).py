def turn_right():
    turn_left()
    turn_left()
    turn_left()
while not wall_in_front():
    move()
while not wall_on_right():
    turn_right()
turn_left()
while not at_goal():
    if right_is_clear():
        turn_right()
        move()
    elif front_is_clear():
        move()
    else:
        turn_left()
    
    
